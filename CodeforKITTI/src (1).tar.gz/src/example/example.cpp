/*
 * Author: Konstantin Schauwecker
 * Year:   2012
 */
 
// This is a minimalistic example on how to use the extended
// FAST feature detector and the sparse stereo matcher.

#include <opencv2/opencv.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <vector>
#include <iostream>
#include <sparsestereo/exception.h>
#include <sparsestereo/extendedfast.h>
#include <sparsestereo/stereorectification.h>
#include <sparsestereo/sparsestereo-inl.h>
#include <sparsestereo/census-inl.h>
#include <sparsestereo/imageconversion.h>
#include <sparsestereo/censuswindow.h>
 #include <fstream>

using namespace std;
using namespace cv;
using namespace sparsestereo;
using namespace boost;
using namespace boost::posix_time;

string getFileName(int lexer);
void comparingOfDisparityMap(vector<SparseMatch> correspondences, int lexer,string LeftpathName, string RightpathName, string fileType,string filename);
void occGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename);
void nonoccGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename);
void initializeOutputDataVariables(int lexer);
void printToAFile(int lexer);
vector<KeyPoint> getKeyPoints(Mat image);

float OCCexFastResultwithinError1[500];
float OCCexFastResultwithinError2[500];
float OCCexFastResultwithinError3[500];
float OCCexFastResulterrorMoreThan3[500];
int OCCexFastResultNumberOfFeatures[500];
float OCCexFastResultinvalidPoint[500];

float NOCexFastResultwithinError1[500];
float NOCexFastResultwithinError2[500];
float NOCexFastResultwithinError3[500];
float NOCexFastResulterrorMoreThan3[500];
int NOCexFastResultNumberOfFeatures[500];
float NOCexFastResultinvalidPoint[500];
ofstream myfile;

float maxfx = 0.0 ;
int main(int argc, char** argv) {
	myfile.open ("actualExFastOutputData.txt");
	try {
		// Stereo matching parameters
		double uniqueness = 0.7;
		int maxDisp = 70;
		int leftRightStep = 2;
		
		// Feature detection parameters
		double adaptivity = 1.0;
		int minThreshold = 10;
		
		// Parse arguments
		// if(argc != 3 && argc != 4) {
		// 	cout << "Usage: " << argv[0] << " LEFT-IMG RIGHT-IMG [CALIBRARION-FILE]" << endl;
		// 	return 1;
		// }
		// char* leftFile = argv[1];
		// char* rightFile = argv[2];
		// char* calibFile = argc == 4 ? argv[3] : NULL;

 		char* calibFile = NULL;
		// int count=0;
		 string LeftpathName  = "/home/n1502596a/Documents/Piyush/SparseSetero Code/Baselines/training/image_0/";
		 string RightpathName  = "/home/n1502596a/Documents/Piyush/SparseSetero Code/Baselines/training/image_1/";
		 string fileType = ".png";	
		 int lexer;
		// Read input images
		for(lexer = 0 ; lexer <194;lexer++)
		 {
		 	cout<<"Lexer = "<<lexer<<endl;
		 	string filename = getFileName(lexer);
			cv::Mat_<unsigned char> leftImg, rightImg;
			leftImg = imread(LeftpathName+filename+fileType, CV_LOAD_IMAGE_GRAYSCALE);
			rightImg = imread(RightpathName+filename+fileType, CV_LOAD_IMAGE_GRAYSCALE);
					cout<<" line 66"<<endl;

			if(leftImg.data == NULL || rightImg.data == NULL)
				throw sparsestereo::Exception("Unable to open input images!");

		// Load rectification data
			StereoRectification* rectification = NULL;
				if(calibFile != NULL)
					rectification = new StereoRectification(CalibrationResult(calibFile));
		
		// The stereo matcher. SSE Optimized implementation is only available for a 5x5 window
			SparseStereo<CensusWindow<5>, short> stereo(maxDisp, 1, uniqueness,
				rectification, false, false, leftRightStep);
			
		// Feature detectors for left and right image
		//FeatureDetector* leftFeatureDetector = new ExtendedFAST(true, minThreshold, adaptivity, false, 2);
		//FeatureDetector* rightFeatureDetector = new ExtendedFAST(false, minThreshold, adaptivity, false, 2);

		ptime lastTime = microsec_clock::local_time();
		vector<SparseMatch> correspondences;
		
		// Objects for storing final and intermediate results
		cv::Mat_<char> charLeft(leftImg.rows, leftImg.cols),
			charRight(rightImg.rows, rightImg.cols);
		Mat_<unsigned int> censusLeft(leftImg.rows, leftImg.cols),
			censusRight(rightImg.rows, rightImg.cols);
		vector<KeyPoint> keypointsLeft, keypointsRight;
		cout<<" line 93"<<endl;
		// For performance evaluation we do the stereo matching 100 times
		for(int i=0; i< 1; i++) {
			// Featuredetection. This part can be parallelized with OMP
			#pragma omp parallel sections default(shared) num_threads(2)
			{
				#pragma omp section
				{
	//cout<<" line 101"<<endl;

					ImageConversion::unsignedToSigned(leftImg, &charLeft);
										//	cout<<" line 104"<<endl;

					Census::transform5x5(charLeft, &censusLeft);
										//	cout<<" line 107"<<endl;

					keypointsLeft.clear();
					keypointsLeft= getKeyPoints(leftImg);
						cout<<" line 110"<<endl;
				//	leftFeatureDetector->detect(leftImg, keypointsLeft);
					//	cout<<" line 106"<<endl;
				}
				#pragma omp section
				{
					ImageConversion::unsignedToSigned(rightImg, &charRight);
					Census::transform5x5(charRight, &censusRight);
					keypointsRight.clear();
					keypointsRight= getKeyPoints(rightImg);
					//rightFeatureDetector->detect(rightImg, keypointsRight);
				}
			}
				cout<<" line 114"<<endl;
			// Stereo matching. Not parallelized (overhead too large)
			correspondences.clear();
			stereo.match(censusLeft, censusRight, keypointsLeft, keypointsRight, &correspondences);
			//cout<<" line 118"<<endl;
		}
		
		// Print statistics
		time_duration elapsed = (microsec_clock::local_time() - lastTime);
		cout << "Time for 100x stereo matching: " << elapsed.total_microseconds()/1.0e6 << "s" << endl
			<< "Features detected in left image: " << keypointsLeft.size() << endl
			<< "Features detected in right image: " << keypointsRight.size() << endl
			<< "Percentage of matched features: " << (100.0 * correspondences.size() / keypointsLeft.size()) << "%" << endl;

		// Highlight matches as colored boxes
		// Mat_<Vec3b> screen(leftImg.rows, leftImg.cols);
		// cvtColor(leftImg, screen, CV_GRAY2BGR);
		
		// for(int i=0; i<(int)correspondences.size(); i++) {
		// 	double scaledDisp = (double)correspondences[i].disparity() / maxDisp;
		// 	Vec3b color;
		// 	if(scaledDisp > 0.5)
		// 		color = Vec3b(0, (1 - scaledDisp)*512, 255);
		// 	else color = Vec3b(0, 255, scaledDisp*512);
			
		// 	rectangle(screen, correspondences[i].imgLeft->pt - Point2f(2,2),
		// 		correspondences[i].imgLeft->pt + Point2f(2, 2), 
		// 		(Scalar) color, CV_FILLED);
		// }

		comparingOfDisparityMap(correspondences,lexer,LeftpathName,RightpathName,fileType,filename);
		// Display image and wait
		// namedWindow("Stereo");
		// imshow("Stereo", screen);
		// waitKey(3);
		
		// Clean up
		// delete leftFeatureDetector;
		// delete rightFeatureDetector;
		if(rectification != NULL)
			delete rectification;
			
		}

		printToAFile(lexer);
	}
	catch (const std::exception& e) {
		cerr << "Fatal exception: " << e.what();
		return 1;
	}
	myfile.close();
}
vector<KeyPoint> getKeyPoints(Mat image)
{
		//cout<<"Line 151"<<endl;

		Mat inputImage = image.clone(); //has to be 8 bit single channel
		//	cout<<"Line 154"<<endl;

		Mat edges;
		Canny( inputImage,edges, 20, 20*10,3 );
		//cout<<"Line 158"<<endl;

	//	imshow("edges",edges);
	//	RNG rng(12345);
		vector<KeyPoint> keypoints ;

		 vector<vector<Point> > contours;
		  vector<Vec4i> hierarchy;
		  findContours(edges, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point(0, 0));
		  		//		cout<<"Line 167"<<endl;

		  for(int i=0; i< contours.size();i++)
		  {
			  for(int j=0;j<contours[i].size();j++)
			  {
		    		keypoints.push_back(cv::KeyPoint(contours[i].at(j), 1.f));
			  }
		  }
			 return keypoints;


}

void printToAFile(int lexer)
{
	//to a matlab file 
	ofstream matlabFile;
	 float OCCaverage=0 ; 
	 float NOCaverage=0 ; 
	 cout<<"Now parsing the files Total = "<<lexer<<endl;
	matlabFile.open ("actualExFast.txt");
	float OCCaverageForexFast = 0 ;
	float NOCaverageForexFast = 0 ;
	
		for(int j=0;j<lexer;j++)
		{
			OCCaverageForexFast = OCCaverageForexFast + OCCexFastResultwithinError1[j]/OCCexFastResultNumberOfFeatures[j] + OCCexFastResultwithinError2[j]/OCCexFastResultNumberOfFeatures[j] +  OCCexFastResultwithinError3[j]/OCCexFastResultNumberOfFeatures[j] ; 
			NOCaverageForexFast = NOCaverageForexFast + NOCexFastResultwithinError1[j]/NOCexFastResultNumberOfFeatures[j] + NOCexFastResultwithinError2[j]/NOCexFastResultNumberOfFeatures[j] +  NOCexFastResultwithinError3[j]/NOCexFastResultNumberOfFeatures[j] ; 
			cout<<"No of features = "<<OCCexFastResultNumberOfFeatures[j]<<endl;
		}
		NOCaverage =  (NOCaverageForexFast/lexer)*100;
		OCCaverage = (OCCaverageForexFast/lexer)*100 ; 
		cout<<"No of features" <<endl;
		matlabFile<<NOCaverage <<endl; 
		matlabFile<<OCCaverage <<endl;
		matlabFile.close();
		
}


string getFileName(int lexer)
{
		string filename =""; 

		int count = lexer;
		 int decimalPlaces = 0 ;
		 int decimalOuput = -1;
		 while(decimalOuput!=0)
		 {
		 	decimalOuput = count/10;
		 	count = count/10 ;
		 	decimalPlaces++ ; 
		 }
		 for(int i = 0 ;i<6-decimalPlaces;i++)
		 {
		 	filename = filename +"0";
		 } 
		 stringstream ss;
		 ss << lexer;
		 string fileNumber = ss.str();

		 filename = filename + fileNumber +"_10";
		 return filename;
}
void initializeOutputDataVariables(int lexer)
{


 OCCexFastResultwithinError1[lexer] = 0;
 OCCexFastResultwithinError2[lexer] = 0;
 OCCexFastResultwithinError3[lexer] = 0;
 OCCexFastResulterrorMoreThan3[lexer] = 0;
 OCCexFastResultNumberOfFeatures[lexer] = 0;
 OCCexFastResultinvalidPoint[lexer] = 0;

 NOCexFastResultwithinError1[lexer] = 0;
 NOCexFastResultwithinError2[lexer] = 0;
 NOCexFastResultwithinError3[lexer] = 0;
 NOCexFastResulterrorMoreThan3[lexer] = 0;
 NOCexFastResultNumberOfFeatures[lexer] = 0;
 NOCexFastResultinvalidPoint[lexer] = 0;
}

void comparingOfDisparityMap(vector<SparseMatch> correspondences, int lexer,string LeftpathName, string RightpathName, string fileType,string filename)
{
	occGTCompare(correspondences,lexer,fileType,filename);
	nonoccGTCompare(correspondences,lexer,fileType,filename);

}




void nonoccGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename)
{
	string fileDirectory = "/home/n1502596a/Documents/Piyush/SparseSetero Code/Baselines/training/disp_noc/";
	Mat GT = imread(fileDirectory+filename+fileType, -1);
	int totalNumberOfMatchedFeatures = correspondences.size();
	int withinError1= 0 ;
	int withinError2= 0 ; 
	int withinError3=0;
	int errorMoreThan3=0;
	int invalidPoint=0;
	for(int i=0;i<(int)correspondences.size();i++)
	{
		if((float)(GT.at<short>(correspondences[i].imgLeft->pt)) ==0)
			invalidPoint++;
		else
		{
				switch((int)abs((float)correspondences[i].disparity()- (float)(GT.at<short>(correspondences[i].imgLeft->pt))/256.0))
			{
			case 0: withinError1++;
					break;
			case 1 :withinError1++ ; 
					break;
			case 2 :withinError2++;
					break;
			case 3 :withinError3++; 
					break;
			default:errorMoreThan3++;
					break;
			}
		}
	}
	

	 NOCexFastResultwithinError1[lexer] = withinError1;
 	 NOCexFastResultwithinError2[lexer] = withinError2;
	 NOCexFastResultwithinError3[lexer] = withinError3;
	 NOCexFastResulterrorMoreThan3[lexer] = errorMoreThan3;
	 NOCexFastResultNumberOfFeatures[lexer] = totalNumberOfMatchedFeatures;
 	 NOCexFastResultinvalidPoint[lexer] = invalidPoint;



	myfile<<"\nNonOcc Ground Truth Values \n ";
	myfile<<"\nTotal Number Of matched features = "<<totalNumberOfMatchedFeatures<<"\n";
	myfile<<"Percentage Error within 1 disparity ="<<((float)withinError1/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage Error within 2 disparity ="<<((float)withinError2/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage Error within 3 disparity ="<<((float)withinError3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage Error more than 3 disparity ="<<((float)errorMoreThan3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage of Invalid  Points ="<<((float)invalidPoint/(float)totalNumberOfMatchedFeatures)*100<<endl;
	myfile<<"---------------------------------------------------------------------------------------------------------\n \n \n";
}
void occGTCompare(vector<SparseMatch> correspondences, int lexer, string fileType,string filename)
{
	string fileDirectory =  "/home/n1502596a/Documents/Piyush/SparseSetero Code/Baselines/training/disp_occ/";
	Mat GT = imread(fileDirectory+filename+fileType, -1);
	int totalNumberOfMatchedFeatures = correspondences.size();
	int withinError1= 0 ;
	int withinError2= 0 ; 
	int withinError3=0;
	int errorMoreThan3=0;
	int invalidPoint=0;
	for(int i=0;i<(int)correspondences.size();i++)
	{
		if((float)(GT.at<short>(correspondences[i].imgLeft->pt)) ==0)
			invalidPoint++;
		else
		{
				switch((int)abs((float)correspondences[i].disparity()- (float)(GT.at<short>(correspondences[i].imgLeft->pt))/256.0))
			{
			case 0: withinError1++;
					break;
			case 1 :withinError1++ ; 
					break;
			case 2 :withinError2++;
					break;
			case 3 :withinError3++; 
					break;
			default:errorMoreThan3++;
					break;
			}
		}
	}


	 OCCexFastResultwithinError1[lexer] = withinError1;
	 OCCexFastResultwithinError2[lexer] = withinError2;
	 OCCexFastResultwithinError3[lexer] = withinError3;
	 OCCexFastResulterrorMoreThan3[lexer] = errorMoreThan3;
	 OCCexFastResultNumberOfFeatures[lexer] = totalNumberOfMatchedFeatures;
	 OCCexFastResultinvalidPoint[lexer] = invalidPoint;

	myfile<<"\nOcc Ground Truth Values \n ";
	myfile<<"\nTotal Number Of matched features = "<<totalNumberOfMatchedFeatures<<"\n";
	myfile<<"Percentage Error within 1 disparity ="<<((float)withinError1/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage Error within 2 disparity ="<<((float)withinError2/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage Error within 3 disparity ="<<((float)withinError3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage Error more than 3 disparity ="<<((float)errorMoreThan3/(float)totalNumberOfMatchedFeatures)*100<<"\n";
	myfile<<"Percentage of Invalid  Points ="<<((float)invalidPoint/(float)totalNumberOfMatchedFeatures)*100<<endl;
	myfile<<"\n\n||||||||||||||\n \n \n";
}